# Midas-Frontend-Examples
attached are files of example frontends from midas, along with frontends created from scratch. 
All examples that start with 'tmfe', except for tmfe_Razvan, are all examples created from MIDAS. 

